/* script.js */
function addToCart(item) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.push(item);
    localStorage.setItem("cart", JSON.stringify(cart));
    alert(item + " added to cart!");
  }
  
  function loadCart() {
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    const cartList = document.getElementById("cart-list");
    cartList.innerHTML = '';
    cart.forEach(item => {
      const li = document.createElement("li");
      li.textContent = item;
      cartList.appendChild(li);
    });
  }
  
  function clearCart() {
    localStorage.removeItem("cart");
    alert("Cart cleared!");
    location.reload();
  }
  
  function signup(event) {
    event.preventDefault();
    const username = document.getElementById("signup-username").value;
    const password = document.getElementById("signup-password").value;
    localStorage.setItem("user", JSON.stringify({ username, password }));
    alert("Signup successful!");
    window.location.href = "login.html";
  }
  
  function login(event) {
    event.preventDefault();
    const username = document.getElementById("login-username").value;
    const password = document.getElementById("login-password").value;
    const user = JSON.parse(localStorage.getItem("user"));
    if (user && user.username === username && user.password === password) {
      alert("Login successful!");
      window.location.href = "index.html";
    } else {
      alert("Invalid credentials");
    }
  }
  
  // Auto-load cart if on cart page
  if (document.title.includes("Cart")) loadCart();
function filterItems(category) {
  const allCards = document.querySelectorAll('.product-card');
  const buttons = document.querySelectorAll('.category-filters button');

  buttons.forEach(btn => btn.classList.remove('active'));

  if (category === 'all') {
    allCards.forEach(card => card.style.display = 'block');
    document.querySelector(`[onclick="filterItems('all')"]`)?.classList.add('active');
  } else {
    allCards.forEach(card => {
      if (card.classList.contains(category)) {
        card.style.display = 'block';
      } else {
        card.style.display = 'none';
      }
    });
    document.querySelector(`[onclick="filterItems('${category}')"]`)?.classList.add('active');
  }
}
  