Farm Fresh Web Application 🍎

A front-end e-commerce platform for selling fresh produce.

Project Structure

- `frontend/` → HTML, CSS, JS files
- `documentation/` → Final report (PDF) and LaTeX source
- `clickup/` → Gantt chart PDF
- `assets/` → Product images and design assets

Technologies Used

- HTML5, CSS3, JavaScript
- LaTeX (Overleaf)
- ClickUp for task management

 Authors

Asad Gul Khan
Ayesha Khan

